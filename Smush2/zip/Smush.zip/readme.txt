SWE1R Smush

This new Smush.dll allows to play high definition custom cutscenes.


*** Requirements ***

This dll requires:
- Windows 7 or superior


*** Usage ***

To use this dll:

1) rename the original Smush.dll to SmushOrig.dll
2) place the new Smush.dll and Smush.cfg next to it.

Smush.cfg is a config file. Open it with a text editor for more details.

The playable formats are .znm, .mp4, .avi and .wmv.

- znm files are played with the original dll.
- mp4 files are played using Media Foundation.
- avi files and wmv files are played using DirectShow.


*** License ***

SWE1R Smush is licensed under the MIT license. See LICENSE.txt


*** Source code ***

The source code of SWE1R Smush is situated at:
https://github.com/JeremyAnsel/swe1r_Smush


*** Credits ***

- Jérémy Ansel (JeremyaFr)
